
CREATE TYPE public.transfer_status AS ENUM ('draft','approved','in_transit','completed','cancelled');

CREATE TABLE public.warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  location text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.warehouses TO anon, authenticated;
GRANT ALL ON public.warehouses TO service_role;
ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "warehouses open" ON public.warehouses FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku text NOT NULL UNIQUE,
  name text NOT NULL,
  unit text NOT NULL DEFAULT 'pcs',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO anon, authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products open" ON public.products FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.stock_levels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse_id uuid NOT NULL REFERENCES public.warehouses(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (warehouse_id, product_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_levels TO anon, authenticated;
GRANT ALL ON public.stock_levels TO service_role;
ALTER TABLE public.stock_levels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stock open" ON public.stock_levels FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE SEQUENCE public.transfer_ref_seq START 1001;
GRANT USAGE, SELECT ON SEQUENCE public.transfer_ref_seq TO anon, authenticated, service_role;

CREATE TABLE public.stock_transfers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text NOT NULL UNIQUE DEFAULT ('TR-' || nextval('public.transfer_ref_seq')),
  source_warehouse_id uuid NOT NULL REFERENCES public.warehouses(id) ON DELETE RESTRICT,
  dest_warehouse_id uuid NOT NULL REFERENCES public.warehouses(id) ON DELETE RESTRICT,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
  quantity integer NOT NULL CHECK (quantity > 0),
  status public.transfer_status NOT NULL DEFAULT 'draft',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  CONSTRAINT different_warehouses CHECK (source_warehouse_id <> dest_warehouse_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_transfers TO anon, authenticated;
GRANT ALL ON public.stock_transfers TO service_role;
ALTER TABLE public.stock_transfers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "transfers open" ON public.stock_transfers FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE INDEX idx_transfers_status ON public.stock_transfers(status);
CREATE INDEX idx_transfers_created ON public.stock_transfers(created_at DESC);

-- keep updated_at fresh
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_transfers_updated BEFORE UPDATE ON public.stock_transfers
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_stock_updated BEFORE UPDATE ON public.stock_levels
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- status transition guard + stock application on completion
CREATE OR REPLACE FUNCTION public.handle_transfer_status()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  allowed boolean := false;
  src_qty integer;
BEGIN
  IF NEW.status = OLD.status THEN
    IF OLD.status <> 'draft' AND (NEW.quantity <> OLD.quantity
        OR NEW.source_warehouse_id <> OLD.source_warehouse_id
        OR NEW.dest_warehouse_id <> OLD.dest_warehouse_id
        OR NEW.product_id <> OLD.product_id) THEN
      RAISE EXCEPTION 'Only draft transfers can be edited';
    END IF;
    RETURN NEW;
  END IF;

  allowed := CASE
    WHEN OLD.status = 'draft' AND NEW.status IN ('approved','cancelled') THEN true
    WHEN OLD.status = 'approved' AND NEW.status IN ('in_transit','cancelled') THEN true
    WHEN OLD.status = 'in_transit' AND NEW.status IN ('completed','cancelled') THEN true
    ELSE false
  END;

  IF NOT allowed THEN
    RAISE EXCEPTION 'Invalid status transition: % -> %', OLD.status, NEW.status;
  END IF;

  IF NEW.status = 'completed' THEN
    SELECT quantity INTO src_qty FROM public.stock_levels
      WHERE warehouse_id = NEW.source_warehouse_id AND product_id = NEW.product_id FOR UPDATE;

    IF src_qty IS NULL OR src_qty < NEW.quantity THEN
      RAISE EXCEPTION 'Insufficient stock at source warehouse (available: %, required: %)', COALESCE(src_qty,0), NEW.quantity;
    END IF;

    UPDATE public.stock_levels SET quantity = quantity - NEW.quantity
      WHERE warehouse_id = NEW.source_warehouse_id AND product_id = NEW.product_id;

    INSERT INTO public.stock_levels (warehouse_id, product_id, quantity)
    VALUES (NEW.dest_warehouse_id, NEW.product_id, NEW.quantity)
    ON CONFLICT (warehouse_id, product_id)
    DO UPDATE SET quantity = public.stock_levels.quantity + EXCLUDED.quantity, updated_at = now();

    NEW.completed_at := now();
  END IF;

  RETURN NEW;
END; $$;

CREATE TRIGGER trg_transfer_status BEFORE UPDATE ON public.stock_transfers
FOR EACH ROW EXECUTE FUNCTION public.handle_transfer_status();

-- seed data
INSERT INTO public.warehouses (code, name, location) VALUES
  ('WH-NORTH','North Distribution Center','Rotterdam, NL'),
  ('WH-SOUTH','South Fulfilment Hub','Lyon, FR'),
  ('WH-EAST','East Regional Depot','Warsaw, PL'),
  ('WH-WEST','West Coastal Store','Porto, PT');

INSERT INTO public.products (sku, name, unit) VALUES
  ('SKU-1001','Industrial Bearing 40mm','pcs'),
  ('SKU-1002','Hydraulic Hose 2m','pcs'),
  ('SKU-1003','Steel Bolt M12 (box)','box'),
  ('SKU-1004','Conveyor Belt Roll','roll'),
  ('SKU-1005','Safety Helmet','pcs'),
  ('SKU-1006','Lubricant Oil 5L','can');

INSERT INTO public.stock_levels (warehouse_id, product_id, quantity)
SELECT w.id, p.id,
  (abs(hashtext(w.code || p.sku)) % 260) + 20
FROM public.warehouses w CROSS JOIN public.products p;

INSERT INTO public.stock_transfers (source_warehouse_id, dest_warehouse_id, product_id, quantity, status, notes)
SELECT
  (SELECT id FROM public.warehouses WHERE code='WH-NORTH'),
  (SELECT id FROM public.warehouses WHERE code='WH-SOUTH'),
  (SELECT id FROM public.products WHERE sku='SKU-1001'), 25, 'draft', 'Restock for spring campaign';
INSERT INTO public.stock_transfers (source_warehouse_id, dest_warehouse_id, product_id, quantity, status, notes)
SELECT
  (SELECT id FROM public.warehouses WHERE code='WH-EAST'),
  (SELECT id FROM public.warehouses WHERE code='WH-WEST'),
  (SELECT id FROM public.products WHERE sku='SKU-1003'), 40, 'approved', 'Approved by ops lead';
INSERT INTO public.stock_transfers (source_warehouse_id, dest_warehouse_id, product_id, quantity, status, notes)
SELECT
  (SELECT id FROM public.warehouses WHERE code='WH-SOUTH'),
  (SELECT id FROM public.warehouses WHERE code='WH-NORTH'),
  (SELECT id FROM public.products WHERE sku='SKU-1005'), 60, 'in_transit', 'Truck departed 08:15';
INSERT INTO public.stock_transfers (source_warehouse_id, dest_warehouse_id, product_id, quantity, status, notes, completed_at)
SELECT
  (SELECT id FROM public.warehouses WHERE code='WH-WEST'),
  (SELECT id FROM public.warehouses WHERE code='WH-EAST'),
  (SELECT id FROM public.products WHERE sku='SKU-1006'), 15, 'completed', 'Delivered and signed off', now() - interval '2 days';
