import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { Plus, Save } from "lucide-react";
import { toast } from "sonner";

import {
  createWarehouse,
  productsQuery,
  setStockQuantity,
  stockLevelsQuery,
  warehouseSchema,
  warehousesQuery,
  type WarehouseInput,
} from "@/lib/stock";

export const Route = createFileRoute("/warehouses")({
  head: () => ({
    meta: [
      { title: "Warehouses & Stock Levels — StockShift" },
      {
        name: "description",
        content:
          "Create warehouses and maintain per-product stock levels across every location in the network.",
      },
      { property: "og:title", content: "Warehouses & Stock Levels — StockShift" },
      {
        property: "og:description",
        content: "Create warehouses and maintain per-product stock levels.",
      },
    ],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(warehousesQuery);
    context.queryClient.ensureQueryData(productsQuery);
    context.queryClient.ensureQueryData(stockLevelsQuery);
  },
  component: WarehousesPage,
  errorComponent: ({ error }) => (
    <p role="alert" className="panel p-6 text-sm text-destructive">
      {error.message}
    </p>
  ),
  notFoundComponent: () => <p className="panel p-6 text-sm">Nothing here.</p>,
});

const EMPTY: WarehouseInput = { code: "", name: "", location: "" };

function WarehousesPage() {
  const queryClient = useQueryClient();
  const { data: warehouses } = useSuspenseQuery(warehousesQuery);
  const { data: products } = useSuspenseQuery(productsQuery);
  const { data: stock } = useSuspenseQuery(stockLevelsQuery);

  const [form, setForm] = useState<WarehouseInput>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [selected, setSelected] = useState<string | null>(warehouses[0]?.id ?? null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const activeWarehouse = warehouses.find((w) => w.id === selected) ?? warehouses[0];

  const rows = useMemo(() => {
    if (!activeWarehouse) return [];
    return products.map((product) => {
      const level = stock.find(
        (s) => s.warehouse_id === activeWarehouse.id && s.product_id === product.id,
      );
      return { product, quantity: level?.quantity ?? 0 };
    });
  }, [products, stock, activeWarehouse]);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["warehouses"] });
    queryClient.invalidateQueries({ queryKey: ["stock-levels"] });
  };

  const addWarehouse = useMutation({
    mutationFn: createWarehouse,
    onSuccess: () => {
      toast.success("Warehouse created");
      setForm(EMPTY);
      setErrors({});
      invalidate();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const saveStock = useMutation({
    mutationFn: ({ productId, quantity }: { productId: string; quantity: number }) =>
      setStockQuantity(activeWarehouse!.id, productId, quantity),
    onSuccess: (_data, vars) => {
      toast.success("Stock level updated");
      setDrafts((d) => {
        const next = { ...d };
        delete next[vars.productId];
        return next;
      });
      queryClient.invalidateQueries({ queryKey: ["stock-levels"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitWarehouse(event: React.FormEvent) {
    event.preventDefault();
    const parsed = warehouseSchema.safeParse(form);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        fieldErrors[String(issue.path[0])] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    addWarehouse.mutate(parsed.data);
  }

  return (
    <div className="space-y-8">
      <section>
        <h1 className="font-display text-3xl font-bold">Warehouses & stock</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Register locations and keep on-hand quantities accurate for every product.
        </p>
      </section>

      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        <section className="panel h-fit p-5">
          <h2 className="font-display text-lg font-semibold">Add a warehouse</h2>
          <form onSubmit={submitWarehouse} className="mt-4 space-y-4" noValidate>
            <Field label="Code" error={errors["code"]}>
              <input
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="WH-CENTRAL"
                maxLength={20}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40"
              />
            </Field>
            <Field label="Name" error={errors["name"]}>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Central Distribution Center"
                maxLength={80}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40"
              />
            </Field>
            <Field label="Location" error={errors["location"]}>
              <input
                value={form.location ?? ""}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                placeholder="Madrid, ES"
                maxLength={120}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40"
              />
            </Field>
            <button
              type="submit"
              disabled={addWarehouse.isPending}
              className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              <Plus className="size-4" />
              {addWarehouse.isPending ? "Saving…" : "Create warehouse"}
            </button>
          </form>

          <div className="mt-6 space-y-1.5 border-t border-border pt-4">
            <p className="label-caps">Locations ({warehouses.length})</p>
            {warehouses.map((w) => (
              <button
                key={w.id}
                onClick={() => setSelected(w.id)}
                className={`w-full rounded-md px-3 py-2 text-left text-sm transition-colors ${
                  activeWarehouse?.id === w.id
                    ? "bg-secondary font-semibold"
                    : "hover:bg-secondary/60"
                }`}
              >
                <span className="block">{w.name}</span>
                <span className="block text-xs text-muted-foreground">
                  {w.code}
                  {w.location ? ` · ${w.location}` : ""}
                </span>
              </button>
            ))}
          </div>
        </section>

        <section className="panel overflow-hidden">
          <div className="border-b border-border p-4">
            <h2 className="font-display text-lg font-semibold">
              {activeWarehouse ? `Stock at ${activeWarehouse.name}` : "Stock levels"}
            </h2>
            <p className="text-xs text-muted-foreground">
              Edit a quantity and save to correct on-hand inventory.
            </p>
          </div>

          {!activeWarehouse ? (
            <p className="p-8 text-center text-sm text-muted-foreground">
              Create a warehouse to start tracking stock.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-secondary/50 text-left">
                    <th className="label-caps px-4 py-3">Product</th>
                    <th className="label-caps px-4 py-3">SKU</th>
                    <th className="label-caps px-4 py-3 text-right">On hand</th>
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map(({ product, quantity }) => {
                    const draft = drafts[product.id];
                    const dirty = draft !== undefined && Number(draft) !== quantity;
                    return (
                      <tr key={product.id} className="border-b border-border/70 last:border-0">
                        <td className="px-4 py-3 font-medium">{product.name}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{product.sku}</td>
                        <td className="px-4 py-3 text-right">
                          <input
                            type="number"
                            min={0}
                            max={1000000}
                            value={draft ?? String(quantity)}
                            aria-label={`Quantity of ${product.name}`}
                            onChange={(e) =>
                              setDrafts((d) => ({ ...d, [product.id]: e.target.value }))
                            }
                            className="h-9 w-28 rounded-md border border-input bg-background px-2 text-right text-sm tabular-nums outline-none focus:ring-2 focus:ring-ring/40"
                          />
                          <span className="ml-2 text-xs text-muted-foreground">{product.unit}</span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            disabled={!dirty || saveStock.isPending}
                            onClick={() => {
                              const value = Number(draft);
                              if (!Number.isInteger(value) || value < 0) {
                                toast.error("Quantity must be a whole number of zero or more");
                                return;
                              }
                              saveStock.mutate({ productId: product.id, quantity: value });
                            }}
                            className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-semibold transition-colors hover:bg-secondary disabled:opacity-40"
                          >
                            <Save className="size-3.5" />
                            Save
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="label-caps mb-1.5 block">{label}</label>
      {children}
      {error ? <p className="mt-1 text-xs text-destructive">{error}</p> : null}
    </div>
  );
}
