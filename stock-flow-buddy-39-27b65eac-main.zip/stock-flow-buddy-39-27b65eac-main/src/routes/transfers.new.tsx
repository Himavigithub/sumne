import { useMemo, useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useMutation, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

import {
  createTransfer,
  productsQuery,
  stockLevelsQuery,
  transferSchema,
  warehousesQuery,
} from "@/lib/stock";

export const Route = createFileRoute("/transfers/new")({
  head: () => ({
    meta: [
      { title: "New Stock Transfer — StockShift" },
      {
        name: "description",
        content:
          "Raise a stock transfer request between two warehouses with live availability checks before submitting.",
      },
      { property: "og:title", content: "New Stock Transfer — StockShift" },
      {
        property: "og:description",
        content: "Raise a warehouse-to-warehouse stock transfer request.",
      },
    ],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(warehousesQuery);
    context.queryClient.ensureQueryData(productsQuery);
    context.queryClient.ensureQueryData(stockLevelsQuery);
  },
  component: NewTransferPage,
  errorComponent: ({ error }) => (
    <p role="alert" className="panel p-6 text-sm text-destructive">
      {error.message}
    </p>
  ),
  notFoundComponent: () => <p className="panel p-6 text-sm">Nothing here.</p>,
});

const selectClass =
  "h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40";

function NewTransferPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: warehouses } = useSuspenseQuery(warehousesQuery);
  const { data: products } = useSuspenseQuery(productsQuery);
  const { data: stock } = useSuspenseQuery(stockLevelsQuery);

  const [source, setSource] = useState("");
  const [dest, setDest] = useState("");
  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const available = useMemo(() => {
    if (!source || !productId) return null;
    return stock.find((s) => s.warehouse_id === source && s.product_id === productId)?.quantity ?? 0;
  }, [stock, source, productId]);

  const overdraw = available !== null && Number(quantity) > available;

  const submit = useMutation({
    mutationFn: createTransfer,
    onSuccess: (data) => {
      toast.success("Transfer request created");
      queryClient.invalidateQueries({ queryKey: ["transfers"] });
      navigate({ to: "/transfers/$transferId", params: { transferId: data.id } });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    const parsed = transferSchema.safeParse({
      source_warehouse_id: source,
      dest_warehouse_id: dest,
      product_id: productId,
      quantity: Number(quantity),
      notes: notes.trim(),
    });
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        fieldErrors[String(issue.path[0])] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    submit.mutate(parsed.data);
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Back to transfers
      </Link>

      <div>
        <h1 className="font-display text-3xl font-bold">New stock transfer</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Requests start as a draft. Stock only moves once the transfer is completed.
        </p>
      </div>

      <form onSubmit={onSubmit} className="panel space-y-5 p-6" noValidate>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="source" className="label-caps mb-1.5 block">
              Source warehouse
            </label>
            <select
              id="source"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              className={selectClass}
            >
              <option value="">Select…</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.code} — {w.name}
                </option>
              ))}
            </select>
            {errors["source_warehouse_id"] ? (
              <p className="mt-1 text-xs text-destructive">{errors["source_warehouse_id"]}</p>
            ) : null}
          </div>

          <div>
            <label htmlFor="dest" className="label-caps mb-1.5 block">
              Destination warehouse
            </label>
            <select
              id="dest"
              value={dest}
              onChange={(e) => setDest(e.target.value)}
              className={selectClass}
            >
              <option value="">Select…</option>
              {warehouses
                .filter((w) => w.id !== source)
                .map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.code} — {w.name}
                  </option>
                ))}
            </select>
            {errors["dest_warehouse_id"] ? (
              <p className="mt-1 text-xs text-destructive">{errors["dest_warehouse_id"]}</p>
            ) : null}
          </div>

          <div>
            <label htmlFor="product" className="label-caps mb-1.5 block">
              Product
            </label>
            <select
              id="product"
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              className={selectClass}
            >
              <option value="">Select…</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.sku} — {p.name}
                </option>
              ))}
            </select>
            {errors["product_id"] ? (
              <p className="mt-1 text-xs text-destructive">{errors["product_id"]}</p>
            ) : null}
          </div>

          <div>
            <label htmlFor="quantity" className="label-caps mb-1.5 block">
              Quantity
            </label>
            <input
              id="quantity"
              type="number"
              min={1}
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder="0"
              className={selectClass}
            />
            {errors["quantity"] ? (
              <p className="mt-1 text-xs text-destructive">{errors["quantity"]}</p>
            ) : available !== null ? (
              <p className="mt-1 text-xs text-muted-foreground">
                Available at source: <strong>{available}</strong>
              </p>
            ) : null}
          </div>
        </div>

        <div>
          <label htmlFor="notes" className="label-caps mb-1.5 block">
            Notes (optional)
          </label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value.slice(0, 500))}
            rows={3}
            placeholder="Reason for the transfer, carrier details, etc."
            className="w-full rounded-md border border-input bg-background p-3 text-sm outline-none focus:ring-2 focus:ring-ring/40"
          />
          {errors["notes"] ? (
            <p className="mt-1 text-xs text-destructive">{errors["notes"]}</p>
          ) : null}
        </div>

        {overdraw ? (
          <p className="flex items-start gap-2 rounded-md border border-warning/40 bg-warning/10 p-3 text-xs text-warning-foreground">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            Requested quantity exceeds current stock at the source warehouse. The draft can still be
            saved, but completion will be blocked until stock is available.
          </p>
        ) : null}

        <button
          type="submit"
          disabled={submit.isPending}
          className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
        >
          {submit.isPending ? "Creating…" : "Create transfer request"}
          <ArrowRight className="size-4" />
        </button>
      </form>
    </div>
  );
}
