import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { toast } from "sonner";

import { StatusBadge } from "@/components/StatusBadge";
import {
  NEXT_STATUSES,
  STATUS_LABELS,
  TRANSFER_STATUSES,
  formatDate,
  stockLevelsQuery,
  transferQuery,
  updateTransferStatus,
  type TransferStatus,
} from "@/lib/stock";

export const Route = createFileRoute("/transfers/$transferId")({
  head: () => ({
    meta: [
      { title: "Transfer Detail — StockShift" },
      {
        name: "description",
        content:
          "Follow a single stock transfer through approval, dispatch and completion, and see how it affects warehouse stock.",
      },
      { property: "og:title", content: "Transfer Detail — StockShift" },
      {
        property: "og:description",
        content: "Track a stock transfer from approval through to completion.",
      },
    ],
  }),
  loader: ({ context, params }) => {
    context.queryClient.ensureQueryData(transferQuery(params.transferId));
    context.queryClient.ensureQueryData(stockLevelsQuery);
  },
  component: TransferDetailPage,
  errorComponent: ({ error }) => (
    <p role="alert" className="panel p-6 text-sm text-destructive">
      {error.message}
    </p>
  ),
  notFoundComponent: () => <p className="panel p-6 text-sm">Transfer not found.</p>,
});

const TIMELINE: TransferStatus[] = ["draft", "approved", "in_transit", "completed"];

function TransferDetailPage() {
  const { transferId } = Route.useParams();
  const queryClient = useQueryClient();
  const { data: transfer } = useSuspenseQuery(transferQuery(transferId));
  const { data: stock } = useSuspenseQuery(stockLevelsQuery);

  const sourceQty =
    stock.find(
      (s) => s.warehouse_id === transfer.source_warehouse_id && s.product_id === transfer.product_id,
    )?.quantity ?? 0;
  const destQty =
    stock.find(
      (s) => s.warehouse_id === transfer.dest_warehouse_id && s.product_id === transfer.product_id,
    )?.quantity ?? 0;

  const advance = useMutation({
    mutationFn: (status: TransferStatus) => updateTransferStatus(transfer.id, status),
    onSuccess: (_data, status) => {
      toast.success(
        status === "completed"
          ? "Transfer completed — warehouse stock updated"
          : `Transfer marked as ${STATUS_LABELS[status].toLowerCase()}`,
      );
      queryClient.invalidateQueries({ queryKey: ["transfers"] });
      queryClient.invalidateQueries({ queryKey: ["stock-levels"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const nextOptions = NEXT_STATUSES[transfer.status];
  const currentStep = TIMELINE.indexOf(transfer.status);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Back to transfers
      </Link>

      <div className="flex flex-wrap items-center gap-3">
        <h1 className="font-display text-3xl font-bold">{transfer.reference}</h1>
        <StatusBadge status={transfer.status} />
      </div>

      <section className="panel p-6">
        <div className="flex flex-wrap items-center gap-4">
          <div>
            <p className="label-caps">From</p>
            <p className="font-semibold">{transfer.source.name}</p>
            <p className="text-xs text-muted-foreground">
              {transfer.source.code} · {sourceQty} on hand
            </p>
          </div>
          <ArrowRight className="size-5 text-muted-foreground" />
          <div>
            <p className="label-caps">To</p>
            <p className="font-semibold">{transfer.destination.name}</p>
            <p className="text-xs text-muted-foreground">
              {transfer.destination.code} · {destQty} on hand
            </p>
          </div>
          <div className="ml-auto text-right">
            <p className="label-caps">Quantity</p>
            <p className="font-display text-2xl font-bold">
              {transfer.quantity}{" "}
              <span className="text-sm font-medium text-muted-foreground">
                {transfer.products.unit}
              </span>
            </p>
          </div>
        </div>

        <dl className="mt-6 grid gap-4 border-t border-border pt-5 sm:grid-cols-2">
          <div>
            <dt className="label-caps">Product</dt>
            <dd className="text-sm font-medium">
              {transfer.products.name}{" "}
              <span className="text-muted-foreground">({transfer.products.sku})</span>
            </dd>
          </div>
          <div>
            <dt className="label-caps">Created</dt>
            <dd className="text-sm">{formatDate(transfer.created_at)}</dd>
          </div>
          <div>
            <dt className="label-caps">Last updated</dt>
            <dd className="text-sm">{formatDate(transfer.updated_at)}</dd>
          </div>
          <div>
            <dt className="label-caps">Completed</dt>
            <dd className="text-sm">{formatDate(transfer.completed_at)}</dd>
          </div>
          {transfer.notes ? (
            <div className="sm:col-span-2">
              <dt className="label-caps">Notes</dt>
              <dd className="text-sm">{transfer.notes}</dd>
            </div>
          ) : null}
        </dl>
      </section>

      <section className="panel p-6">
        <h2 className="font-display text-lg font-semibold">Progress</h2>
        <ol className="mt-4 flex flex-wrap items-center gap-2">
          {TIMELINE.map((step, index) => {
            const reached = transfer.status !== "cancelled" && index <= currentStep;
            return (
              <li key={step} className="flex items-center gap-2">
                <span
                  className={`rounded-full border px-3 py-1 text-xs font-semibold ${
                    reached
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground"
                  }`}
                >
                  {STATUS_LABELS[step]}
                </span>
                {index < TIMELINE.length - 1 ? (
                  <ArrowRight className="size-3.5 text-muted-foreground" />
                ) : null}
              </li>
            );
          })}
        </ol>

        {transfer.status === "cancelled" ? (
          <p className="mt-5 text-sm text-muted-foreground">
            This transfer was cancelled and no stock was moved.
          </p>
        ) : nextOptions.length === 0 ? (
          <p className="mt-5 text-sm text-muted-foreground">
            This transfer is complete. Stock has been deducted from {transfer.source.code} and added
            to {transfer.destination.code}.
          </p>
        ) : (
          <div className="mt-5 flex flex-wrap gap-2">
            {nextOptions.map((status) => (
              <button
                key={status}
                disabled={advance.isPending}
                onClick={() => advance.mutate(status)}
                className={`rounded-md px-4 py-2 text-sm font-semibold transition-opacity hover:opacity-90 disabled:opacity-60 ${
                  status === "cancelled"
                    ? "border border-destructive/40 text-destructive"
                    : "bg-primary text-primary-foreground"
                }`}
              >
                {status === "cancelled" ? "Cancel transfer" : `Mark as ${STATUS_LABELS[status]}`}
              </button>
            ))}
          </div>
        )}

        <p className="mt-4 text-xs text-muted-foreground">
          Valid path: {TRANSFER_STATUSES.slice(0, 4).map((s) => STATUS_LABELS[s]).join(" → ")}.
          Stock is only moved when a transfer reaches Completed, and completion fails if the source
          warehouse lacks the quantity.
        </p>
      </section>
    </div>
  );
}
