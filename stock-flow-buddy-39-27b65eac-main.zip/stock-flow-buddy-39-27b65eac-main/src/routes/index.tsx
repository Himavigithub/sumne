import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowRight, PackageSearch, Boxes, Truck, CheckCircle2 } from "lucide-react";

import { StatusBadge } from "@/components/StatusBadge";
import {
  STATUS_LABELS,
  TRANSFER_STATUSES,
  formatDate,
  stockLevelsQuery,
  transfersQuery,
  warehousesQuery,
  type TransferStatus,
} from "@/lib/stock";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Stock Transfers — StockShift" },
      {
        name: "description",
        content:
          "Review every warehouse-to-warehouse stock transfer, filter by status, and follow each request from draft to completion.",
      },
      { property: "og:title", content: "Stock Transfers — StockShift" },
      {
        property: "og:description",
        content: "Warehouse-to-warehouse transfer history with live status tracking.",
      },
    ],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(transfersQuery);
    context.queryClient.ensureQueryData(warehousesQuery);
    context.queryClient.ensureQueryData(stockLevelsQuery);
  },
  component: TransfersPage,
  errorComponent: ({ error }) => (
    <p role="alert" className="panel p-6 text-sm text-destructive">
      {error.message}
    </p>
  ),
  notFoundComponent: () => <p className="panel p-6 text-sm">Nothing here.</p>,
});

function StatCard({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  icon: typeof Boxes;
}) {
  return (
    <div className="panel flex items-center gap-4 p-4">
      <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-secondary text-primary">
        <Icon className="size-5" />
      </span>
      <div className="min-w-0">
        <p className="label-caps">{label}</p>
        <p className="font-display text-2xl font-bold leading-tight">{value}</p>
      </div>
    </div>
  );
}

function TransfersPage() {
  const { data: transfers } = useSuspenseQuery(transfersQuery);
  const { data: warehouses } = useSuspenseQuery(warehousesQuery);
  const { data: stock } = useSuspenseQuery(stockLevelsQuery);

  const [status, setStatus] = useState<TransferStatus | "all">("all");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return transfers.filter((t) => {
      if (status !== "all" && t.status !== status) return false;
      if (!term) return true;
      return [t.reference, t.products.name, t.products.sku, t.source.name, t.destination.name]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [transfers, status, search]);

  const totalUnits = stock.reduce((sum, s) => sum + s.quantity, 0);
  const openCount = transfers.filter(
    (t) => t.status !== "completed" && t.status !== "cancelled",
  ).length;
  const completedCount = transfers.filter((t) => t.status === "completed").length;

  return (
    <div className="space-y-8">
      <section>
        <h1 className="font-display text-3xl font-bold">Stock transfers</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Every movement between warehouses, from draft request to completed delivery.
        </p>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Warehouses" value={warehouses.length} icon={Boxes} />
        <StatCard label="Units on hand" value={totalUnits.toLocaleString()} icon={PackageSearch} />
        <StatCard label="Open transfers" value={openCount} icon={Truck} />
        <StatCard label="Completed" value={completedCount} icon={CheckCircle2} />
      </section>

      <section className="panel overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value.slice(0, 100))}
            placeholder="Search reference, product or warehouse…"
            aria-label="Search transfers"
            className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 sm:max-w-xs"
          />
          <div className="flex flex-wrap gap-1.5 sm:ml-auto">
            {(["all", ...TRANSFER_STATUSES] as const).map((s) => (
              <button
                key={s}
                onClick={() => setStatus(s)}
                aria-pressed={status === s}
                className={`rounded-full border px-3 py-1 text-xs font-semibold transition-colors ${
                  status === s
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:bg-secondary"
                }`}
              >
                {s === "all" ? "All" : STATUS_LABELS[s]}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm text-muted-foreground">No transfers match this view.</p>
            <Link
              to="/transfers/new"
              className="mt-4 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
            >
              Create a transfer
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-secondary/50 text-left">
                  <th className="label-caps px-4 py-3">Reference</th>
                  <th className="label-caps px-4 py-3">Product</th>
                  <th className="label-caps px-4 py-3">Route</th>
                  <th className="label-caps px-4 py-3 text-right">Qty</th>
                  <th className="label-caps px-4 py-3">Status</th>
                  <th className="label-caps px-4 py-3">Created</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t.id} className="border-b border-border/70 last:border-0 hover:bg-secondary/40">
                    <td className="px-4 py-3 font-semibold">{t.reference}</td>
                    <td className="px-4 py-3">
                      <p className="font-medium">{t.products.name}</p>
                      <p className="text-xs text-muted-foreground">{t.products.sku}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-2 whitespace-nowrap text-xs">
                        <span className="font-medium">{t.source.code}</span>
                        <ArrowRight className="size-3.5 text-muted-foreground" />
                        <span className="font-medium">{t.destination.code}</span>
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-semibold tabular-nums">
                      {t.quantity} {t.products.unit}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={t.status} />
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs text-muted-foreground">
                      {formatDate(t.created_at)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Link
                        to="/transfers/$transferId"
                        params={{ transferId: t.id }}
                        className="text-xs font-semibold text-primary hover:underline"
                      >
                        Open
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
