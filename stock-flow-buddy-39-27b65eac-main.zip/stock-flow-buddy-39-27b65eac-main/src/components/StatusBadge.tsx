import { cn } from "@/lib/utils";
import { STATUS_LABELS, type TransferStatus } from "@/lib/stock";

const STYLES: Record<TransferStatus, string> = {
  draft: "bg-muted text-muted-foreground border-border",
  approved: "bg-info/10 text-info border-info/30",
  in_transit: "bg-warning/15 text-warning-foreground border-warning/40",
  completed: "bg-success/12 text-success border-success/30",
  cancelled: "bg-destructive/10 text-destructive border-destructive/25",
};

export function StatusBadge({
  status,
  className,
}: {
  status: TransferStatus;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        STYLES[status],
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden />
      {STATUS_LABELS[status]}
    </span>
  );
}
