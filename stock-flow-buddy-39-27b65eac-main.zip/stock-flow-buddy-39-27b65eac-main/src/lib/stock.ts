import { queryOptions } from "@tanstack/react-query";
import { z } from "zod";

import { supabase } from "@/integrations/supabase/client";

export const TRANSFER_STATUSES = [
  "draft",
  "approved",
  "in_transit",
  "completed",
  "cancelled",
] as const;

export type TransferStatus = (typeof TRANSFER_STATUSES)[number];

export const STATUS_LABELS: Record<TransferStatus, string> = {
  draft: "Draft",
  approved: "Approved",
  in_transit: "In transit",
  completed: "Completed",
  cancelled: "Cancelled",
};

/** Allowed forward moves — mirrors the database trigger that enforces them. */
export const NEXT_STATUSES: Record<TransferStatus, TransferStatus[]> = {
  draft: ["approved", "cancelled"],
  approved: ["in_transit", "cancelled"],
  in_transit: ["completed", "cancelled"],
  completed: [],
  cancelled: [],
};

export type Warehouse = {
  id: string;
  code: string;
  name: string;
  location: string | null;
  created_at: string;
};

export type Product = {
  id: string;
  sku: string;
  name: string;
  unit: string;
};

export type StockLevel = {
  id: string;
  warehouse_id: string;
  product_id: string;
  quantity: number;
  updated_at: string;
  products: Product;
  warehouses: Pick<Warehouse, "id" | "code" | "name">;
};

export type Transfer = {
  id: string;
  reference: string;
  quantity: number;
  status: TransferStatus;
  notes: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  source_warehouse_id: string;
  dest_warehouse_id: string;
  product_id: string;
  source: Pick<Warehouse, "id" | "code" | "name">;
  destination: Pick<Warehouse, "id" | "code" | "name">;
  products: Product;
};

const TRANSFER_SELECT = `
  id, reference, quantity, status, notes, created_at, updated_at, completed_at,
  source_warehouse_id, dest_warehouse_id, product_id,
  source:warehouses!stock_transfers_source_warehouse_id_fkey (id, code, name),
  destination:warehouses!stock_transfers_dest_warehouse_id_fkey (id, code, name),
  products (id, sku, name, unit)
`;

function unwrap<T>(result: { data: T | null; error: { message: string } | null }): T {
  if (result.error) throw new Error(result.error.message);
  return result.data as T;
}

export const warehousesQuery = queryOptions({
  queryKey: ["warehouses"],
  queryFn: async () =>
    unwrap<Warehouse[]>(
      await supabase.from("warehouses").select("*").order("code", { ascending: true }),
    ),
});

export const productsQuery = queryOptions({
  queryKey: ["products"],
  queryFn: async () =>
    unwrap<Product[]>(
      await supabase.from("products").select("id, sku, name, unit").order("sku"),
    ),
});

export const stockLevelsQuery = queryOptions({
  queryKey: ["stock-levels"],
  queryFn: async () =>
    unwrap<StockLevel[]>(
      await supabase
        .from("stock_levels")
        .select(
          "id, warehouse_id, product_id, quantity, updated_at, products (id, sku, name, unit), warehouses (id, code, name)",
        )
        .order("quantity", { ascending: false }),
    ),
});

export const transfersQuery = queryOptions({
  queryKey: ["transfers"],
  queryFn: async () =>
    unwrap<Transfer[]>(
      await supabase
        .from("stock_transfers")
        .select(TRANSFER_SELECT)
        .order("created_at", { ascending: false }),
    ),
});

export const transferQuery = (id: string) =>
  queryOptions({
    queryKey: ["transfers", id],
    queryFn: async () =>
      unwrap<Transfer>(
        await supabase.from("stock_transfers").select(TRANSFER_SELECT).eq("id", id).single(),
      ),
  });

export const warehouseSchema = z.object({
  code: z
    .string()
    .trim()
    .min(2, "Code must be at least 2 characters")
    .max(20, "Code must be 20 characters or fewer")
    .regex(/^[A-Za-z0-9-]+$/, "Use letters, numbers and hyphens only"),
  name: z.string().trim().min(2, "Name is required").max(80, "Name is too long"),
  location: z.string().trim().max(120, "Location is too long").optional().or(z.literal("")),
});

export type WarehouseInput = z.infer<typeof warehouseSchema>;

export const transferSchema = z
  .object({
    source_warehouse_id: z.string().uuid("Select a source warehouse"),
    dest_warehouse_id: z.string().uuid("Select a destination warehouse"),
    product_id: z.string().uuid("Select a product"),
    quantity: z
      .number({ invalid_type_error: "Enter a quantity" })
      .int("Quantity must be a whole number")
      .positive("Quantity must be greater than zero")
      .max(1_000_000, "Quantity is unrealistically large"),
    notes: z.string().trim().max(500, "Notes must be 500 characters or fewer").optional(),
  })
  .refine((v) => v.source_warehouse_id !== v.dest_warehouse_id, {
    message: "Source and destination must be different warehouses",
    path: ["dest_warehouse_id"],
  });

export type TransferInput = z.infer<typeof transferSchema>;

export async function createWarehouse(input: WarehouseInput) {
  const { error } = await supabase.from("warehouses").insert({
    code: input.code.toUpperCase(),
    name: input.name,
    location: input.location || null,
  });
  if (error) throw new Error(error.message);
}

export async function createTransfer(input: TransferInput) {
  const { data, error } = await supabase
    .from("stock_transfers")
    .insert({
      source_warehouse_id: input.source_warehouse_id,
      dest_warehouse_id: input.dest_warehouse_id,
      product_id: input.product_id,
      quantity: input.quantity,
      notes: input.notes || null,
    })
    .select("id")
    .single();
  if (error) throw new Error(error.message);
  return data as { id: string };
}

export async function updateTransferStatus(id: string, status: TransferStatus) {
  const { error } = await supabase.from("stock_transfers").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);
}

export async function setStockQuantity(
  warehouseId: string,
  productId: string,
  quantity: number,
) {
  const { error } = await supabase
    .from("stock_levels")
    .upsert(
      { warehouse_id: warehouseId, product_id: productId, quantity },
      { onConflict: "warehouse_id,product_id" },
    );
  if (error) throw new Error(error.message);
}

export function formatDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
